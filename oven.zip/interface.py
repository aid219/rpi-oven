import pygame
import json
import time
from PIL import Image


class UI:
    def __init__(self, config_path):
        pygame.init()
        pygame.font.init()
        
        # Прямой вывод в framebuffer (для RPI без X11)
        try:
            import os
            os.environ["SDL_VIDEODRIVER"] = "kmsdrm"
            self.screen = pygame.display.set_mode((480, 320), pygame.FULLSCREEN)
        except:
            self.screen = pygame.display.set_mode((480, 320))
        
        pygame.display.set_caption('Oven Control')
        self.clock = pygame.time.Clock()
        self.font = pygame.font.Font(None, 36)
        self.small_font = pygame.font.Font(None, 28)
        
        # Загружаем конфиг
        with open(config_path) as f:
            self.config = json.load(f)
        
        self.buttons = self.config.get('buttons', {})
        self.animations = self.config.get('animations', {})
        self.labels = self.config.get('labels', {})
        
        # Загружаем GIF анимации
        self.gif_frames = {}
        self.gif_index = {}
        self.gif_playing = {}  # Состояние: играет/остановлен
        for name, anim in self.animations.items():
            if 'gif' in anim:
                self.gif_frames[name] = self.load_gif(anim['gif'])
                self.gif_index[name] = 0
                self.gif_playing[name] = False  # По умолчанию остановлена
        
        # Состояние анимаций
        self.anim_state = {}
        for name, anim in self.animations.items():
            self.anim_state[name] = {
                'scale': 1.0,
                'direction': -1,
                'alpha': 255
            }
        
        # Статус печи
        self.oven_on = False
        self.temperature = 0
    
    def load_gif(self, path):
        """Загрузить GIF как список кадров pygame.Surface"""
        try:
            gif = Image.open(path)
            frames = []
            for frame in range(gif.n_frames):
                gif.seek(frame)
                rgb = gif.convert('RGB')
                img = pygame.image.fromstring(rgb.tobytes(), rgb.size, 'RGB')
                frames.append(img)
            return frames
        except Exception as e:
            print(f"Error loading GIF {path}: {e}")
            return []
    
    def draw_button(self, name, btn):
        x, y = btn['x'], btn['y']
        w, h = btn['width'], btn['height']
        color = tuple(btn['color'])
        text = btn['text']
        
        # Рисуем кнопку
        pygame.draw.rect(self.screen, color, (x, y, w, h), border_radius=10)
        pygame.draw.rect(self.screen, (255, 255, 255), (x, y, w, h), 2, border_radius=10)
        
        # Текст
        text_surf = self.font.render(text, True, (255, 255, 255))
        text_rect = text_surf.get_rect(center=(x + w//2, y + h//2))
        self.screen.blit(text_surf, text_rect)
    
    def draw_animation(self, name, anim):
        x, y = anim['x'], anim['y']
        w, h = anim['width'], anim['height']
        state = self.anim_state[name]
        
        # Если есть GIF - рисуем его
        if name in self.gif_frames and self.gif_frames[name]:
            frames = self.gif_frames[name]
            if frames:
                # Если играет - переключаем кадры, иначе показываем первый
                if self.gif_playing.get(name, False):
                    frame = frames[self.gif_index.get(name, 0)]
                    self.gif_index[name] = (self.gif_index.get(name, 0) + 1) % len(frames)
                else:
                    frame = frames[0]  # Первый кадр когда остановлен
                
                # Масштабируем под размер
                scaled = pygame.transform.smoothscale(frame, (w, h))
                self.screen.blit(scaled, (x, y))
            return
        
        # Иначе - пульсирующий круг
        size = int(min(w, h) * state['scale'])
        
        # Внешний круг (волны)
        if self.oven_on:
            wave_size = size + int(20 * (1 - state['scale']))
            pygame.draw.circle(self.screen, (255, 100, 100), (x + w//2, y + h//2), wave_size, 3)
        
        # Основной круг (сердце)
        color = (255, 0, 0) if self.oven_on else (150, 150, 150)
        pygame.draw.circle(self.screen, color, (x + w//2, y + h//2), size // 2)
        
        # Обновляем состояние анимации
        state['scale'] += state['direction'] * 0.03
        if state['scale'] < 0.8 or state['scale'] > 1.0:
            state['direction'] *= -1
    
    def draw_label(self, name, label):
        x, y = label['x'], label['y']
        font_size = label['font_size']
        text = label['text']
        
        font = pygame.font.Font(None, font_size)
        text_surf = font.render(text, True, (255, 255, 255))
        self.screen.blit(text_surf, (x, y))
    
    def draw(self):
        self.screen.fill((30, 30, 50))
        
        # Рисуем кнопки
        for name, btn in self.buttons.items():
            self.draw_button(name, btn)
        
        # Рисуем анимации
        for name, anim in self.animations.items():
            self.draw_animation(name, anim)
        
        # Рисуем лейблы
        for name, label in self.labels.items():
            self.draw_label(name, label)
        
        pygame.display.flip()
    
    def handle_input(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return 'quit'
            
            if event.type == pygame.MOUSEBUTTONDOWN:
                x, y = event.pos
                
                # Проверяем клик по кнопкам
                for name, btn in self.buttons.items():
                    if (btn['x'] <= x <= btn['x'] + btn['width'] and
                        btn['y'] <= y <= btn['y'] + btn['height']):
                        return btn['action']
                
                # Проверяем клик по анимациям
                for name, anim in self.animations.items():
                    if (anim['x'] <= x <= anim['x'] + anim['width'] and
                        anim['y'] <= y <= anim['y'] + anim['height']):
                        return f'anim_{name}'
            
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    return 'quit'
        
        return None
    
    def toggle_animation(self, name):
        """Переключить анимацию вкл/выкл"""
        if name in self.gif_playing:
            self.gif_playing[name] = not self.gif_playing[name]
            if not self.gif_playing[name]:
                self.gif_index[name] = 0  # Сброс на первый кадр
    
    def start_animation(self, name):
        """Запустить анимацию"""
        if name in self.gif_playing:
            self.gif_playing[name] = True
    
    def stop_animation(self, name):
        """Остановить анимацию"""
        if name in self.gif_playing:
            self.gif_playing[name] = False
            self.gif_index[name] = 0  # Сброс на первый кадр
    
    def update_status(self, status):
        if 'temp' in self.labels:
            self.labels['temp']['text'] = f"Temperature: {status['temp']}°C"
        self.oven_on = status.get('on', False)
    
    def close(self):
        pygame.quit()
