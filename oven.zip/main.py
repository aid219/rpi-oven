#!/usr/bin/env python3
"""
Oven Control - Main Logic
Логика управления печью (не меняется при смене интерфейса)
"""

from interface import UI
import time
import random


class Oven:
    def __init__(self):
        self.ui = UI('config.json')
        self.oven_on = False
        self.target_temp = 0
        self.current_temp = 20
    
    def toggle_oven(self):
        """Переключить печь вкл/выкл"""
        self.oven_on = not self.oven_on
        if self.oven_on:
            print("TOGGLE: Включаем печь...")
            self.target_temp = 200
            self.ui.toggle_animation('heart')
        else:
            print("TOGGLE: Выключаем печь...")
            self.target_temp = 0
            self.ui.toggle_animation('heart')
    
    def start_oven(self):
        """Включить печь"""
        print("START: Включаем печь...")
        self.oven_on = True
        self.target_temp = 200
        self.ui.start_animation('heart')
    
    def stop_oven(self):
        """Выключить печь"""
        print("STOP: Выключаем печь...")
        self.oven_on = False
        self.target_temp = 0
        self.ui.stop_animation('heart')
    
    def update_temperature(self):
        """Симуляция изменения температуры"""
        if self.oven_on and self.current_temp < self.target_temp:
            self.current_temp += random.randint(1, 3)
        elif not self.oven_on and self.current_temp > 20:
            self.current_temp -= random.randint(1, 2)
        return self.current_temp
    
    def run(self):
        """Главный цикл"""
        print("Oven Control запущен. ESC для выхода. Клик на GIF - вкл/выкл.")
        
        running = True
        last_temp_update = time.time()
        
        while running:
            # Обработка ввода
            event = self.ui.handle_input()
            
            if event == 'quit':
                running = False
            elif event == 'toggle_oven':
                self.toggle_oven()
            elif event == 'anim_heart':
                self.toggle_oven()
            elif event == 'start_oven':
                self.start_oven()
            elif event == 'stop_oven':
                self.stop_oven()
            
            # Обновление температуры (раз в секунду)
            if time.time() - last_temp_update > 1:
                temp = self.update_temperature()
                self.ui.update_status({
                    'temp': temp,
                    'on': self.oven_on
                })
                last_temp_update = time.time()
            
            # Отрисовка
            self.ui.draw()
            self.ui.clock.tick(30)  # 30 FPS
        
        self.ui.close()
        print("Oven Control остановлен.")


if __name__ == '__main__':
    oven = Oven()
    oven.run()
